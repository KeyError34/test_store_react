# @redux-saga/testing-utils

## 1.1.5

### Patch Changes

- [#2324](https://github.com/redux-saga/redux-saga/pull/2324) [`2466c79`](https://github.com/redux-saga/redux-saga/commit/2466c798a5f56a5015e61c8fdf0ef8f2a6a852a4) Thanks [@neurosnap](https://github.com/neurosnap)! - Add LICENSE file

- Updated dependencies [[`2466c79`](https://github.com/redux-saga/redux-saga/commit/2466c798a5f56a5015e61c8fdf0ef8f2a6a852a4)]:
  - @redux-saga/symbols@1.1.3
  - @redux-saga/types@1.2.1

## 1.1.4

### Patch Changes

- [#2297](https://github.com/redux-saga/redux-saga/pull/2297) [`fdca798`](https://github.com/redux-saga/redux-saga/commit/fdca7989d5b8325b4a685de984ca121769c23ab0) Thanks [@lourd](https://github.com/lourd)! - Adds missing isAborted method to mock task and deprecates its setRunning method

- Updated dependencies [[`bed4458`](https://github.com/redux-saga/redux-saga/commit/bed4458a79f21fd568a9d970968c9c8b8cbe1bf4), [`612cae8`](https://github.com/redux-saga/redux-saga/commit/612cae81f0b8e6eb01b0b4c9ed961906be1fea98), [`20f22a8`](https://github.com/redux-saga/redux-saga/commit/20f22a8edd3bc66c2373ad31fb2c81e9bfed435f), [`d2579a2`](https://github.com/redux-saga/redux-saga/commit/d2579a204c6fa75105a74c999542dfc331697c21)]:
  - @redux-saga/types@1.2.0
