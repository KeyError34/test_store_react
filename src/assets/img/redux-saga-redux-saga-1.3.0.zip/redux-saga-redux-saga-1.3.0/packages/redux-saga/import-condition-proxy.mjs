export * from './dist/redux-saga-core-npm-proxy.cjs.js'
import _default from './dist/redux-saga-core-npm-proxy.cjs.js'

export default _default.default
