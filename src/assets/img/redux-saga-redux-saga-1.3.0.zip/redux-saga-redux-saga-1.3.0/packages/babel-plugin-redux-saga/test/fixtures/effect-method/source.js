function* test1() {
  yield foo.bar(1, 2, 3)
}
