export function* test1() {
  yield foo(1, 2, 3)
}

export default function* test2() {
  yield 2
}
