to recompile sources run
```bash
npx tsc test/fixtures/typescript/source.ts --sourceMap -t es2015 -m es2015
```
