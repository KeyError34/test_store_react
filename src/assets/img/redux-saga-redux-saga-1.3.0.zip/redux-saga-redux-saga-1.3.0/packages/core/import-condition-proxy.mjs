export * from './dist/redux-saga-core.cjs.js'
import _default from './dist/redux-saga-core.cjs.js'

export default _default.default
