export let current = 0

export default () => ++current
