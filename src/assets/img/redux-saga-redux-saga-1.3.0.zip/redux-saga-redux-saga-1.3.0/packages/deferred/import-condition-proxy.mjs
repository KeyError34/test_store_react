export * from './dist/redux-saga-deferred.cjs.js'
import _default from './dist/redux-saga-deferred.cjs.js'

export default _default.default
