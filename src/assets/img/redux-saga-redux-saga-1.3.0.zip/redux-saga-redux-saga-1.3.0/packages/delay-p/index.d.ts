export default function delayP<T = true>(ms: number, val?: T): Promise<T>
