export * from './dist/redux-saga-delay-p.cjs.js'
import _default from './dist/redux-saga-delay-p.cjs.js'

export default _default.default
