export const selectedRedditSelector = (state) => state.selectedReddit
export const postsByRedditSelector = (state) => state.postsByReddit
