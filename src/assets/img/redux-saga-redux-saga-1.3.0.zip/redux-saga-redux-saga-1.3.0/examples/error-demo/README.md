# Run locally

`npm start`

# Open in browser

[Click here](https://codesandbox.io/s/github/redux-saga/redux-saga/tree/main/examples/error-demo)

_Note_ babel-plugin doesn't work yet on codesanbox.
