# Security policy

## Supported versions

The latest version of the project is currently supported with security updates.

## Reporting a vulnerability

You can report a vulnerability by contacting maintainers via email.
